## zkLink | Changelog

### 1.3.1 (2020-12-23)
* Renaming to zkLink
* Adding link to Github sources

### 1.3.0 (2020-12-23)
* Renaming to zkSync Link
* Adding firebase deployment
* Adding zkSync logo

### 1.3.0 (2020-12-15)
* Add social media sharing links

### 1.2.0 (2020-12-10)
* Update app icons
* Logo @ page header

### 1.1.0 (2020-12-09)
* Highlight required fields
* Add todos to the Readme
* Renaming to PayNow
* Some CSS spacings

### 1.0.0 (2020-12-08)
* Initial release
