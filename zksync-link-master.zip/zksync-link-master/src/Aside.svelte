<script>

</script>

<style>
    aside {
        min-height: 100vh;
        min-width: 25rem;
        width: 30%;
        flex: 0;
        flex-basis: 30%;
        padding: 5rem 0 2rem;
        background: var(--color-aside-background);
        display: none;
        justify-content: space-between;
        flex-direction: column;
        overflow: hidden;
        text-align: center;
    }

    h1 {
        font-size: 2rem;
        line-height: 2.5rem;
    }

    img {
        display: block;
        width: 100%;
        height: auto;
    }

    @media (min-width: 1024px) {
        aside {
            display: flex;
        }
    }
</style>

<aside>
    <h1>
        Create zkSync payment links,
        <br>
        get paid in tokens
    </h1>

    <img src="images/artwork.svg" loading="lazy" alt="Artwork">
</aside>
