export const HOME_URL = `${window.location.protocol}//${window.location.host}${window.location.pathname}`;
export const TOKENS_API = 'https://api.zksync.io/api/v0.1/tokens';
export const TWEET_URL = 'https://twitter.com/intent/tweet?url=';
export const SHARER_URL = 'https://www.facebook.com/sharer/sharer.php?u=';
